from setuptools import setup

setup(name='distributed_prob',
      version='1.0',
      description='Gaussian and Binomial distributions',
      packages=['distributed_prob'],
      author = "Prerna Singh",
      author_email = "writeprernasingh@gmail.com",
    zip_safe=False)
